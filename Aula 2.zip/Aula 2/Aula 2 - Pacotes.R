# Antonio Carlos Porto, 12.09.24
# Aula 2


#######################################################################################
########################## Pacotes ####################################################
#######################################################################################

#### Instalando pacotes 

install.packages("fBasics")
install.packages("ggplot2")
install.packages("car")
install.packages("ExpDes")
install.packages("agricolae")
install.packages("asbio")
install.packages("latticeExtra")




